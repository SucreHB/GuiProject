package GuiHomework;

public class OneThousand {
	public static void main (String [] args) 
	{
		for(int x = 1; x < 1001; x++) 
		{
			while (x%2==0) 
			{
				System.out.println(x);
			}
		}
	}

}
